# Evaluation Report — H-002

## Retrieval Quality  
Full RAG significantly outperforms baselines.

## Hallucination  
- RAG: 0%  
- LLM-only: 12%

## Latency  
~420 ms average.

RAG + personalization clearly improves customer experience quality.
